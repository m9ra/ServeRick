﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MikePound.Parsing.Maths
{
    /// <summary>
    /// Represents a standard matrix exception
    /// </summary>
    class MatrixException : Exception
    {
        public MatrixException(String Message)
            : base(Message)
        {
        }
    }

    /// <summary>
    /// Represents a matrix size exception. Where an operation has been attempted on matrices of incompatible sizes.
    /// </summary>
    class MatrixSizeException : MatrixException
    {
        public MatrixSizeException()
            : base("The Matrix or Matrices supplied are of incorrect size.")
        {
        }
    }

    /// <summary>
    /// Class for storing matrices and providing basic operations on these structures.
    /// </summary>
    public class Matrix
    {
        #region Variables
        private int rows;
        public int Rows
        {
            get { return this.rows; }
        }

        private int cols;
        public int Cols
        {
            get { return this.cols; }
        }

        private double[,] data;
        #endregion
        
        #region Constructors
        /// <summary>
        /// Creates a new Matrix.
        /// </summary>
        /// <param name="r">The number of rows in the matrix.</param>
        /// <param name="c">The number of columns in the matrix.</param>
        public Matrix(int r, int c)
        {
            this.rows = r;
            this.cols = c;
            this.data = CreateData(r, c);
        }

        /// <summary>
        /// Creates a new matrix with an equal number of rows and columns.
        /// </summary>
        /// <param name="r">The number of rows and columns in the matrix.</param>
        public Matrix(int r)
        {
            this.rows = r;
            this.cols = r;
            this.data = CreateData(r,r);
        }
        #endregion

        #region Memory Allocation
        private double[,] CreateData(int r, int c)
        {
            double[,] data = new double[r,c];
            for (int i = 0; i < r; i++)
                for (int j = 0; j < c; j++)
                    data[i, j] = 0;
            return data;
        }

        private static double[,] CopyData(Matrix data)
        {
            int r = data.Rows;
            int c = data.Cols;
            double[,] dataOut = new double[r, c];
            for (int i = 0; i < r; i++)
                for (int j = 0; j < c; j++)
                    dataOut[i, j] = data[i,j];
            return dataOut;
        }
        #endregion

        #region Indexers
        public double this[int r, int c]
        {
            get
            {
                return this.data[r, c];
            }
            set
            {
                this.data[r, c] = value;
            }
        }
        #endregion

        #region Operators
        public static Matrix operator +(Matrix M1, Matrix M2)
        {
            if ((M1.Rows != M2.Rows) || (M1.Cols != M2.Cols))
            {
                throw new MatrixSizeException();
            }
            else
            {
                Matrix temp = new Matrix(M1.Rows, M1.Cols);
                for (int i = 0; i < M1.Rows; i++)
                    for (int j = 0; j < M1.Cols; j++)
                        temp[i,j] = M1[i,j] + M2[i,j]; 
                return temp;
            }
        }

        public static Matrix operator -(Matrix M1, Matrix M2)
        {
            if ((M1.Rows != M2.Rows) || (M1.Cols != M2.Cols))
            {
                throw new MatrixSizeException();
            }
            else
            {
                Matrix temp = new Matrix(M1.Rows, M1.Cols);
                for (int i = 0; i < M1.Rows; i++)
                    for (int j = 0; j < M1.Cols; j++)
                        temp[i, j] = M1[i, j] - M2[i, j];
                return temp;
            }
        }

        public static Matrix operator *(Matrix M1, Matrix M2)
        {
            if (M1.Cols != M2.Rows)
            {
                throw new MatrixSizeException();
            }
            else
            {
                Matrix temp = new Matrix(M1.Rows, M2.Cols);
                for (int i = 0; i < M1.Rows; i++)
                    for (int j = 0; j < M2.Cols; j++)
                    {
                        temp[i,j] = 0.0;
                        for (int k = 0; k < M1.Cols; k++)
                            temp[i,j] += M1[i,k] * M2[k,j];
                    }
                return temp;
            }
        }

        public static Matrix operator *(double s, Matrix M2)
        {
            Matrix temp = new Matrix(M2.Rows, M2.Cols);
            for (int i = 0; i < M2.Rows; i++)
                for (int j = 0; j < M2.Cols; j++)
                    temp[i, j] = s * M2[i, j];
            return temp;
        }

        public static Matrix operator *(Matrix M1, double s)
        {
            Matrix temp = new Matrix(M1.Rows, M1.Cols);
            for (int i = 0; i < M1.Rows; i++)
                for (int j = 0; j < M1.Cols; j++)
                    temp[i, j] = s * M1[i, j];
            return temp;
        }
        #endregion

        #region Helpers
        /// <summary>
        /// Creates a new instance of the identity matrix of a given size.
        /// </summary>
        /// <param name="r">The number of rows and columns in the returned matrix.</param>
        /// <returns>Identity matrix of size r x r</returns>
        public static Matrix Identity(int r)
        {
            Matrix temp = new Matrix(r);
            for (int i = 0; i < r; i++)
            {
                temp[i, i] = 1;
            }
            return temp;
        }
        
        /// <summary>
        /// Creates a new instance of Maths.Matrix that is the inversion of the supplied Maths.Matrix.
        /// </summary>
        /// <param name="M">The matrix to be inverted.</param>
        public static Matrix Inverse(Matrix M)
        {
            // Uses Gauss-Jordan elimination
            if (M.rows != M.cols)
                throw new MatrixSizeException();

            Matrix GJ = new Matrix(M.rows, M.cols * 2);
            for (int i = 0; i < GJ.Rows; i++)
            {
                for (int j = 0; j < GJ.Cols; j++)
                {
                    if (j < M.Rows)
                        GJ[i, j] = M[i, j];
                    else if (i == (j - M.Rows))
                        GJ[i, j] = 1;
                    else
                        GJ[i, j] = 0;
                }
            }

            for (int c = 0; c < M.Cols; c++)
            {
                if (GJ[c, c] == 0)
                {
                    // Need to interchange rows
                    int swapc = -1;
                    for (int newc = c + 1; newc < GJ.Cols; c++)
                        if (GJ[newc, c] != 0)
                            swapc = newc;
                    if (swapc == -1)
                    {
                        // no row to swap with
                        throw new MatrixException("Singular exception during Matrix Inversion");
                    }
                    else
                    {
                        double temp;
                        for (int i = 0; i < GJ.Rows; i++)
                        {
                            temp = GJ[c, i];
                            GJ[c, i] = GJ[swapc, i];
                            GJ[swapc, i] = temp;
                        }
                    }


                }
                // divide through by M[c][c] to make M[c][c] 1
                double mcc = GJ[c, c];
                for (int i = 0; i < GJ.Cols; i++)
                    GJ[c, i] = GJ[c, i] / mcc;
                // For each other row, r, subtract M[r][c] * row c to zero elements
                for (int r = 0; r < GJ.Rows; r++)
                    if (r != c)
                    {
                        double mult = GJ[r, c];
                        for (int i = 0; i < GJ.Cols; i++)
                            GJ[r, i] -= mult * GJ[c, i];
                    }
            }

            Matrix Inv = new Matrix(M.Rows, M.Cols);
            for (int i =0; i < Inv.Rows; i++)
                for (int j =0; j < Inv.Cols; j++)
                    Inv[i,j] = GJ[i,j+Inv.Cols];
            return Inv;
        }

        /// <summary>
        /// Creates a new instance of Maths.Matrix that is the transposition of the supplied Maths.Matrix.
        /// </summary>
        /// <param name="M">The matrix to be transposed.</param>
        public static Matrix Transpose(Matrix M)
        {
            Matrix temp = new Matrix(M.Cols, M.Rows);
            for (int i = 0; i < M.Rows; i++)
                for (int j = 0; j < M.Cols; j++)
                    temp[i, j] = M[j, i];
            return temp;
        }

        /// <summary>
        /// Creates a new instance of Maths.Matrix with the same value as the specified Maths.Matrix.
        /// </summary>
        /// <param name="M">The matrix to be copied</param>
        public static Matrix Copy(Matrix M)
        {
            Matrix M2 = new Matrix(M.Rows, M.Cols);
            M2.data = CopyData(M);
            return M2;
        }
        #endregion
    }
}
