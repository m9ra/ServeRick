﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MikePound.Parsing.Data
{
    /// <summary>
    /// Class representing a Node in the SyntaxTree.
    /// </summary>
    public class SyntaxTreeNode
    {
        #region Variables
        private string symbol;
        public string Symbol
        {
            get
            {
                return symbol;
            }
            set
            {
                symbol = value;
            }
        }

        private double forwardProbability;
        public double ForwardProbability
        {
            get
            {
                return forwardProbability;
            }
            set
            {
                forwardProbability = value;
            }
        }

        private List<SyntaxTreeNode> children;
        public List<SyntaxTreeNode> Children
        {
            get
            {
                return children;
            }
        }
        #endregion

        #region Constructors
        /// <summary>
        /// Creates a new instance of SyntaxTreeNode based on the supplied parameters.
        /// </summary>
        /// <param name="Symbol">The symbol the node.</param>
        /// <param name="ForwardProbability">The forward probability of the node.</param>
        public SyntaxTreeNode(string Symbol, double ForwardProbability)
        {
            this.symbol = String.Copy(Symbol);
            this.forwardProbability = ForwardProbability;
            this.children = new List<SyntaxTreeNode>();
        }
        #endregion
    }

    /// <summary>
    /// Class representing an abstract syntax tree produced by the probabilistic Earley chart parser.
    /// </summary>
    public class SyntaxTree
    {
        #region Variables
        private SyntaxTreeNode root;
        public SyntaxTreeNode Root
        {
            get
            {
                return root;
            }
            set
            {
                root = value;
            }
        }
        #endregion

        #region Contructors
        /// <summary>
        /// Initializes a new SyntaxTree with a null root node.
        /// </summary>
        public SyntaxTree()
        {
            this.root = null;
        }
        #endregion

        #region Helpers
        public override string ToString()
        {
            return RecursiveString(this.root, 0);
        }

        private string RecursiveString(SyntaxTreeNode Root, int padding)
        {
            if (Root == null)
                return "";

            string s = "";
            string b = "";
            string n = "";
            for (int z = padding; z > 0; z--)
            {
                b += "  ";
            }
            if (Root.Symbol == "")
            {
                for (int z = 4; z > 0; z--)
                {
                    n += " ";
                }
                s += b + "Root [" + Root.ForwardProbability.ToString() + "]";
            }
            else if (Symbol.IsNonTerminal(Root.Symbol))
            {
                for (int z = Root.Symbol.Length; z > 0; z--)
                {
                    n += " ";
                }
                s += b + Root.Symbol;
            }
            else
            {
                for (int z = Root.Symbol.Length; z > 0; z--)
                {
                    n += " ";
                }
                s += b + Root.Symbol + " [" + Root.ForwardProbability.ToString() + "]";
            }

            if (Root.Children.Count > 0)
                s += "\r\n" + b + "{  \r\n";
            for (int x = 0; x < Root.Children.Count; x++)
            {
                s += RecursiveString(Root.Children[x], padding + 2) + "\r\n ";
            }
            if (Root.Children.Count > 0)
                s += b + "} ";
            return s;
        }

        /// <summary>
        /// Outputs an RTF string that colour codes the different symbols in the tree. Nesting is also shown using tabs.
        /// </summary>
        /// <returns></returns>
	    public string ToRtf()
	    {
		    string Header = "{\\rtf1\\ansi\\deff0"
			    + "{\\fonttbl{\\f0\\fmodern\\fprq1\\fcharset0 Courier New;}}"
			    + "{\\colortbl ;\\red255\\green0\\blue0;\\red0\\green0\\blue255;\\red0\\green155\\blue0;\\red255\\green128\\blue0;\\red200\\green0\\blue200;\\red100\\green255\\blue100;}\\fs18";
		    string Footer = "}";
		    string Output = string.Copy(Header);
		
		    Output += RecursiveRtf(this.Root, 0);

		    Output += Footer;
		    return Output;
	    }
    
        private string RecursiveRtf(SyntaxTreeNode Root, int padding) 
        {
	        if (Root == null)
		        return "";
		
	        string s = "";
	        string b = "";
	        string n = "";
	        for (int z = padding; z >0; z--)
	        {
		        b += "  ";
	        }
	        if (Root.Symbol == "")
	        {
		        for (int z = 4; z > 0; z--)
		        {
			        n += " ";
		        }
		        s += b + "\\cf1 Root [" + Root.ForwardProbability.ToString() +"]\\cf0 ";
	        }
	        else if (Symbol.IsNonTerminal(Root.Symbol))
	        {
		        for (int z = Root.Symbol.Length; z > 0; z--)
		        {
			        n += " ";
		        }
		        s += b + "\\cf2 " + Root.Symbol + "\\cf0 ";
	        }
	        else
	        {
		        for (int z = Root.Symbol.Length; z > 0; z--)
		        {
			        n += " ";
		        }
		        s += b + "\\cf3 " + Root.Symbol + " [" + Root.ForwardProbability.ToString() +"]\\cf0 ";
	        }

	        if (Root.Children.Count > 0)
		        s += "\\par\\cf0 " + b + "\\{  \\par ";
	        for (int x = 0; x < Root.Children.Count; x++)
	        {
		        s += RecursiveRtf(Root.Children[x], padding + 2) + "\\par ";
	        }
	        if (Root.Children.Count > 0)
		        s += b  + "\\cf0 \\} ";
	        return s;
        }
        #endregion
    }
}
