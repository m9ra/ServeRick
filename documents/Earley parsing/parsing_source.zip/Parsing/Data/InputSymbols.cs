﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MikePound.Parsing.Data
{
    /// <summary>
    /// Class representing a single input token and attached probability. Also provides a static method for determining whether
    /// a symbol is a non-terminal.
    /// </summary>
    public struct Symbol
    {
        #region Variables
        private string token;
        public string Token
        {
            get
            {
                return token;
            }
        }

        private double probability;
        public double Probability
        {
            get
            {
                return probability;
            }
        }
        #endregion

        #region Constructors
        /// <summary>
        /// Initializes a new input symbol with the supplied parameters.
        /// </summary>
        /// <param name="Symbol">The token for the input symbol.</param>
        /// <param name="Probability">The probability of this input symbol.</param>
        public Symbol(string Symbol, double Probability)
        {
            this.token = Symbol;
            this.probability = Probability;
        }
        #endregion

        #region Helpers
        /// <summary>
        /// Calculates whether a string represents a non terminal based on the capitalisation of the first character in the string.
        /// </summary>
        /// <param name="S">The string being examined.</param>
        /// <returns>True if the string represents a non-terminal character in a grammar.</returns>
        public static bool IsNonTerminal(String S)
        {
            return !(S[0] < 65 || S[0] > 90);
        }
        #endregion
    }

    /// <summary>
    /// Data structure that contains groups of input symbols for use in the Earley chart parser.
    /// </summary>
    public class InputSymbols
    {
        #region Variables
        private List<Symbol>[] symbols;
        public List<Symbol> this[int i]
        {
            get
            {
                return this.symbols[i];
            }
        }

        public int Length
        {
            get
            {
                return this.symbols.Length;
            }
        }
        #endregion

        #region Constructors
        /// <summary>
        /// Initializes a new InputSymbols structure of a given length.
        /// </summary>
        /// <param name="Size">The length of the eventual input string.</param>
        public InputSymbols (int Size)
        {
            this.symbols = new List<Symbol>[Size];
            for (int i = 0; i < Size; i++)
            {
                this.symbols[i] = new List<Symbol>();
            }
        }
        #endregion

        #region Methods
        /// <summary>
        /// Adds a symbol to the InputSymbols structure.
        /// </summary>
        /// <param name="Index">The index at which to add the new symbol.</param>
        /// <param name="Token">The token of the symbol.</param>
        /// <param name="Probability">The probability attached to the token.</param>
        public void AddSymbolAt(int Index, string Token, double Probability)
        {
            this.symbols[Index].Add(new Symbol(Token, Probability));
        }
        #endregion
    }
}
