﻿using System;
using System.Collections.Generic;
using System.Text;

using MikePound.Parsing.IO;
using MikePound.Parsing.Earley;

namespace MikePound.Parsing.Data
{
    #region Exceptions
    /// <summary>
    /// Represents an exception thrown when a parsing error has occured when reading a grammar text file.
    /// </summary>
    class GrammarParsingException : MikePound.Parsing.Earley.ParsingException
    {
        public GrammarParsingException(String Message)
            : base("Error parsing grammar file (" + Message + ")")
        {
        }
        public GrammarParsingException(String Message, Exception e)
            : base("Error parsing grammar file (" + Message + ")", e)
        {
        }
    }
    /// <summary>
    /// Represents an exception thrown when a structural problem is detected in a parsed grammar.
    /// </summary>
    class GrammarStructureException : MikePound.Parsing.Earley.ParsingException
    {
        public GrammarStructureException(String Message)
            : base("Invalid Structure (" + Message + ")")
        {
        }
        public GrammarStructureException(String Message, Exception e)
            : base("Invalid Structure: " + Message, e)
        {
        }
    }
    #endregion

    public class Grammar
    {
        #region Variables
        private string root;
        public string Root
        {
            get
            {
                return root;
            }
        }

        private List<Production> productions;
        public List<Production> Productions
        {
            get
            {
                return productions;
            }
        }

        private List<string> identifiers;
        public List<string> Identifiers
        {
            get
            {
                return identifiers;
            }
        }
        #endregion

        #region Constructors
        /// <summary>
        /// Initializes a new grammar with default parameters.
        /// </summary>
        public Grammar()
        {
            this.root = "";
            this.productions = new List<Production>();
            this.identifiers = new List<string>();
        }

        /// <summary>
        /// Initializes a new grammar with default parameters, and then parses a supplied file to load structure.
        /// </summary>
        /// <param name="Path"></param>
        public Grammar(string Path)
        {
            this.root = "";
            this.productions = new List<Production>();
            this.identifiers = new List<string>();
            ParseGrammarFile(Path);
        }
        #endregion

        #region Helpers
        /// <summary>
        /// Loads and parses a grammar text file into a set of productions for use by a parser.
        /// </summary>
        /// <param name="Path">The path of the file to be loaded.</param>
        public void ParseGrammarFile(string Path)
        {
            // Load FileReader
            FileReader reader = null;
            try
            {
                reader = new FileReader(Path);
            }
            catch (FileReaderException e)
            { 
                if (reader != null)
                    reader.Close();
                throw new GrammarParsingException("Error parsing Grammar file", e);
            }

            // Variable Declarations and Initialisations
            this.root = "";
            this.productions.Clear();
            this.identifiers.Clear();
            string previousNonterminal = "";
            string currentNonterminal = "";
            string currentWord = "";
            double currentProbability = 0.0;
            List<string> currentDerivations = new List<string>();
            int lineNumber = 0;

            // Loop for all lines of the input file
            while (reader.NewLine())
            {
                lineNumber++;
                currentDerivations.Clear();
                previousNonterminal = currentNonterminal;
                currentNonterminal = "";
                currentProbability = -1.0;
                bool nLine = true;
                bool comment = false;
                while (true)
                {
                    currentWord = reader.GetWord();
                    if (currentWord == null)
                        break;

                    // Parse word
                    if (currentWord == "")
                    {
                        continue;
                    }
                    else if (currentWord == "->")
                    {
                        nLine = false;
                    }
                    else if (currentWord[0] == '[')
                    {
                        bool parseSuccess = Double.TryParse(currentWord.Substring(1, currentWord.Length - 2), out currentProbability);
                        if (!parseSuccess)
                        {
                            reader.Close();
                            throw new GrammarParsingException("Invalid probability: " + currentWord.Substring(1, currentWord.Length - 2) + " - line " + lineNumber.ToString());
                        }
                    }
                    else if (currentWord[0] == '#')
                    {
                        comment = true;
                        break;
                    }
                    else if (nLine)
                    {
                        if (currentWord == "|")
                        {
                            currentNonterminal = String.Copy(previousNonterminal);
                            nLine = false;
                            if (previousNonterminal == "")
                            {
                                reader.Close();
                                throw new GrammarParsingException("Derivation RHS does not have matching LHS - line " + lineNumber.ToString());
                            }
                        }
                        else
                        {
                            currentNonterminal = String.Copy(currentWord);
                        }
                    }
                    else if (!nLine)
                    {
                        currentDerivations.Add(String.Copy(currentWord));
                    }
                }
                // Perform checks then create the Production rule
                if (currentProbability <= 0.0 || currentProbability > 1.0)
                {
                    if (comment)
                        continue;
                    reader.Close();
                    throw new GrammarParsingException("Invalid probability found: " + currentProbability.ToString() + " - line " + lineNumber.ToString());
                }
                else if (currentDerivations.Count == 0)
                {
                    if (comment)
                        continue;
                    reader.Close();
                    throw new GrammarParsingException("Expected RHS of production rule");
                }

                // Update Identifier list if necessary
                if (identifiers.IndexOf(currentNonterminal) < 0)
                {
                    identifiers.Add(String.Copy(currentNonterminal));
                }

                // Create finished production
                Production P = new Production(currentNonterminal, currentDerivations.ToArray(), currentProbability);
                this.productions.Add(P);
            }

            // Finish and assert structure
            reader.Close();

            try
            {
                AssertStructure();
            }
            catch (GrammarStructureException)
            {
                throw;
            }


        }

        /// <summary>
        /// Asserts whether the structure of a grammar is correct. Will throw a GrammarStructuralException if not.
        /// </summary>
        public void AssertStructure()
        {
            int rootNodes = 0;
            if (this.productions.Count == 0)
                throw new GrammarStructureException("Grammar is Empty");

            // For each production rule
            for (int currentProduction = 0; currentProduction < this.productions.Count; currentProduction++)
            {
                // Make sure the LHS is a non terminal
                if (!Symbol.IsNonTerminal(this.productions[currentProduction].LHS))
                    throw new GrammarStructureException("Terminal symbol found on the LHS of a production" + " - line " + (currentProduction + 1).ToString());

                // Make sure all nonterminals on the RHS are on the LHS of at least 1 production rule
                for (int currentSymbol = 0; currentSymbol < this.productions[currentProduction].RHS.Length; currentSymbol++)
                {
                    if(Symbol.IsNonTerminal(this.productions[currentProduction].RHS[currentSymbol]))
                    {
                        bool foundLHSSymbol = false;
                        for (int currentSubProduction = 0; currentSubProduction < this.productions.Count; currentSubProduction++)
                        {
                            if (this.productions[currentSubProduction].LHS == this.productions[currentProduction].RHS[currentSymbol])
                            {
                                foundLHSSymbol = true;
                                break;
                            }
                        }
                        if (!foundLHSSymbol)
                            throw new GrammarStructureException("Derivation for RHS Nonterminal not found" + " - line " + (currentProduction+1).ToString());
                    }
                }

                // Including all other occurences of this Nonterminal on the LHS
                double totalProbability = 0.0;
                bool foundNonDuplicate = false;
                bool reachable = false;
                for (int currentSubProduction = 0; currentSubProduction < this.productions.Count; currentSubProduction++)
                {
                    // Ensure RHSs include something other than LHS only (prevent looping)
                    // Ensure probabilities add to 1.0
                    // Ensure Nonterminal is reachable
                    if (this.productions[currentSubProduction].LHS == this.productions[currentProduction].LHS)
                    {
                        totalProbability += this.productions[currentSubProduction].Probability;
                        for (int currentSymbol = 0; currentSymbol < this.productions[currentSubProduction].RHS.Length; currentSymbol++)
                        {
                            if (this.productions[currentSubProduction].RHS[currentSymbol] != this.productions[currentSubProduction].LHS)
                                foundNonDuplicate = true;
                        }
                    }
                    for (int currentSymbol = 0; currentSymbol < this.productions[currentSubProduction].RHS.Length; currentSymbol++)
                    {
                        if (this.productions[currentProduction].LHS == this.productions[currentSubProduction].RHS[currentSymbol]
                            && this.productions[currentSubProduction].RHS[currentSymbol] != this.productions[currentSubProduction].LHS)
                            reachable = true;
                    }
                    
                }
               
                if (!reachable)
                {
                    if (this.productions[currentProduction].LHS != this.root)
                    {
                        rootNodes++;
                        this.root = String.Copy(this.productions[currentProduction].LHS);
                    }
                }
                if (!foundNonDuplicate)
                    throw new GrammarStructureException("Recursive only production found" + " - line " + (currentProduction + 1).ToString());
                if (System.Math.Round(totalProbability,2) != 1.0)
                    throw new GrammarStructureException("Probabilities of all RHS derivations for a Nonterminal must sum to 1.0" + " - Current symbol: " + this.productions[currentProduction].LHS);
                

                if (rootNodes < 1)
                    this.root = String.Copy(this.productions[0].LHS);
                else if (rootNodes > 1)
                    throw new GrammarStructureException("Multiple root productions found");

            }
       
        }
        #endregion
    }
}
