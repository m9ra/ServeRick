﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using MikePound.Parsing.Earley;

namespace MikePound.Parsing.Data
{
    /// <summary>
    /// Contains a state that has been queued. Also includes a set index, that represents the required
    /// set position of the state once it has been completed.
    /// </summary>
    class QueueState
    {
        #region Variables
        private State state;
        public State State
        {
            get
            {
                return state;
            }
        }

        private int setIndex;
        public int SetIndex
        {
            get
            {
                return setIndex;
            }
        }
        #endregion

        #region Constructors
        /// <summary>
        /// Creates a new instance of QueueState.
        /// </summary>
        /// <param name="S">The state to be queued.</param>
        /// <param name="I">The required index of that state upon completion.</param>
        public QueueState(State S, int I)
        {
            this.state = S;
            this.setIndex = I;
        }
        #endregion
    }

    /// <summary>
    /// A queue that stores scanned states awaiting completion. States are ordered first by their origin (parent) index, then by a standard queue FIFO approach.
    /// </summary>
    class CompletionQueue
    {
        #region Variables
        private Queue<QueueState>[] pendingStates;
        #endregion

        #region Constructors
        public CompletionQueue(int Size)
        {
            pendingStates = new Queue<QueueState>[Size];
            for (int i = 0; i < Size; i++)
            {
                pendingStates[i] = new Queue<QueueState>();
            }
        }
        #endregion

        #region Queue Methods
        /// <summary>
        /// Adds a state S to the completion queue.
        /// </summary>
        /// <param name="S">The state to be queued.</param>
        public void Enqueue(QueueState S)
        {
            this.pendingStates[S.State.Origin].Enqueue(S);
        }

        /// <summary>
        /// Removes the next state from the completion queue and returns it. States with higher origins are returned first, then in a FIFO order.
        /// </summary>
        /// <returns></returns>
        public QueueState Dequeue()
        {
            for (int i = pendingStates.Length - 1; i >= 0; i--)
            {
                if (pendingStates[i].Count > 0)
                {
                    return pendingStates[i].Dequeue();
                }
            }
            return null;
        }

        /// <summary>
        /// Indicates whether the queue is currently empty.
        /// </summary>
        public bool IsEmpty
        {
            get
            {
                for (int i = 0; i < pendingStates.Length; i++)
                {
                    if (pendingStates[i].Count > 0)
                    {
                        return false;
                    }
                }
                return true;
            }
        }
        #endregion
    }
}
