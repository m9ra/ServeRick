﻿using System;
using System.IO;

namespace MikePound.Parsing.IO
{
    /// <summary>
    /// Represents an exception thrown by the FileReader class.
    /// </summary>
    class FileReaderException : System.IO.IOException
    {
        public FileReaderException(String Message, Exception InnerException)
            : base(Message, InnerException)
        {
        }
    }

    /// <summary>
    /// Wrapper around the StreamReader class providing some helpful methods for obtainling lines in order and splitting these lines
    /// into string arrays.
    /// </summary>
    public class FileReader
    {
        #region Variables
        String[] currentLine;
	    int currentLineIndex;
	    char[] deliminators;
	    StreamReader streamReader;
        #endregion

        #region Constructors
        /// <summary>
        /// Creates a new FileReader that opens a StreamReader on a file.
        /// </summary>
        /// <param name="path">The path of the file to be opened.</param>
        public FileReader(String path)
        {
            currentLine = null;
            currentLineIndex = 0;
            deliminators = new char[] {' ', '\n', '\t'};

            try
            {
                streamReader = new StreamReader(path);
            }
            catch (System.IO.FileNotFoundException e)
            {
                throw new FileReaderException("File Read Error.", e);
            }

        }

        ~FileReader()
        {
            this.Close();
        }
        #endregion

        #region Methods
        /// <summary>
        /// Loads the next line into the stream reader.
        /// </summary>
        /// <returns>True if the next line has been successfully read. False if the end of the file has been reached.</returns>
        public bool NewLine()
        {
            if (streamReader.Peek() >= 0)
            {
                // Read in next line
                currentLine = streamReader.ReadLine().Split(deliminators);
                currentLineIndex = 0;
                return true;
            }
            else
            {
                currentLine = null;
                currentLineIndex = 0;
                return false;
            }
        }

        /// <summary>
        /// Gets the next word of the current line.
        /// </summary>
        /// <returns>A string containing the next word, or null if the end of the line has been reached.</returns>
        public string GetWord()
        {
            if (currentLineIndex >= this.currentLine.Length)
                return null;
            else
            {
                return String.Copy(this.currentLine[currentLineIndex++]);
            }
        }

        /// <summary>
        /// Closes the file.
        /// </summary>
        public void Close()
        {
            this.currentLine = null;
            if (this.streamReader != null)
            {
                this.streamReader.Close();
                this.streamReader = null;
            }
        }
        #endregion
    }
}
