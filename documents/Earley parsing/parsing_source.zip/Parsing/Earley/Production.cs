﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MikePound.Parsing.Earley
{
    /// <summary>
    /// Class that implements a production structure for a probabilistic parser. Includes a production rule and attached probability.
    /// </summary>
    public class Production
    {
        #region Variables
        private string lhs;
        public string LHS
        {
            get
            {
                return lhs;
            }
        }

        private string[] rhs;
        public string[] RHS
        {
            get
            {
                return rhs;
            }
        }

        private double probability;
        public double Probability
        {
            get
            {
                return probability;
            }
        }
        #endregion

        #region Contructors
        /// <summary>
        /// Creates a new instance of Production with the supplied properties.
        /// </summary>
        /// <param name="LHS">A string containing the left hand side of the production rule.</param>
        /// <param name="RHS">A string array containing all right hand side derivations of the production rule.</param>
        /// <param name="p">The probability of this production rule.</param>
        public Production(string LHS, string[] RHS, double p)
        {
            this.lhs = String.Copy(LHS);
            this.rhs = new string[RHS.Length];
            Array.Copy(RHS, 0, rhs, 0, RHS.Length);
            this.probability = p;
        }

        #endregion

        #region Helpers
        /// <summary>
        /// Creates a new instance of Earley.Production based on the supplied Earley.Production
        /// </summary>
        /// <param name="Input">The Production to be copied.</param>
        public static Production Copy(Production Input)
        {
            return new Production(Input.LHS, Input.RHS, Input.Probability);
        }

        /// <summary>
        /// Compares a production with another.
        /// </summary>
        /// <param name="P2">The Production that this with be compared with.</param>
        /// <returns>True if the two productions are identical, false if not.</returns>
        public bool Equals(Production P2)
        {
            if ((this.LHS != P2.LHS) || this.Probability != P2.Probability)
                return false;
            if (this.RHS.Length != P2.RHS.Length)
                return false;
            for (int i = 0; i < this.RHS.Length; i++)
            {
                if (this.RHS[i] != P2.RHS[i])
                    return false;
            }
            return true;
        }
        #endregion
    }
}
