﻿using System;
using System.Collections.Generic;
using System.Text;

using MikePound.Parsing.Data;
using MikePound.Parsing.Maths;

namespace MikePound.Parsing.Earley
{
    /// <summary>
    /// Represents a generic parsing exception
    /// </summary>
    class ParsingException : System.Exception
    {
        public ParsingException(String Message)
            : base(Message)
        {
        }
        public ParsingException(String Message, Exception e)
            : base(Message, e)
        {
        }
    }

    public class Parser
    {
        #region Variables
        private List<State>[] states;
        #endregion

        #region Constructors
        /// <summary>
        /// Initializes a new Parser with a null state set. The state set is created during the parsing process.
        /// </summary>
        public Parser()
        {
            states = null;
        }
        #endregion

        #region Parsing
        /// <summary>
        /// Parses a set of input symbols using the Earley-Stolcke probabilistic chart parser with a stochastic context-free grammar.
        /// </summary>
        /// <param name="grammar">The grammar used by the parser.</param>
        /// <param name="inputString">The lists of input symbols.</param>
        public SyntaxTree Parse(Grammar grammar, InputSymbols inputString)
        {
            // Variable declarations
            int inputStringIndex = 0;
            int ntCount = grammar.Identifiers.Count;

            // Identity matrix
            Matrix I = Matrix.Identity(ntCount);
            // Pl matrix - left-corner relations
            Matrix PL = new Matrix(ntCount);
            // Pu matrix - unit-production relations
            Matrix PU = new Matrix(ntCount);

            for (int r = 0; r < ntCount; r++)
            {
                for (int c = 0; c < ntCount; c++)
                {
                    double currentProbabilityPl = 0.0;
                    double currentProbabilityPu = 0.0;
                    for (int currentProduction = 0; currentProduction < grammar.Productions.Count; currentProduction++)
                    {
                        if (grammar.Productions[currentProduction].LHS == grammar.Identifiers[r] && grammar.Productions[currentProduction].RHS[0] == grammar.Identifiers[c])
                        {
                            currentProbabilityPl += grammar.Productions[currentProduction].Probability;
                            if (grammar.Productions[currentProduction].RHS.Length == 1)
                            {
                                currentProbabilityPu += grammar.Productions[currentProduction].Probability;
                            }
                        }
                    }
                    PL[r, c] = currentProbabilityPl;
                    PU[r, c] = currentProbabilityPu;
                }
            }

            // Rl Matrix - Left-corner transistive closure
            Matrix RL = Matrix.Inverse(I - PL);
            // Ru Matrix - Unit-production transistive closure
            Matrix RU = Matrix.Inverse(I - PU);

            // Ensure input symbols exist
            if (inputString == null || inputString.Length == 0)
                throw new ParsingException(inputString == null ? "No input string found" : "Empty input string found");

            // Create state sets
            this.states = new List<State>[inputString.Length + 1];
            for (int i = 0; i < states.Length; i++)
            {
                this.states[i] = new List<State>();
            }

            // Initialise completion queue
            CompletionQueue pendingCompletions = new CompletionQueue(this.states.Length);

            // See parser with root
            Production seedProduction = new Production("", new string[] {String.Copy(grammar.Root)}, 1.0);
            this.states[0].Add(new State(seedProduction,0,0,1.0,1.0,1.0));

            // Begin parsing
            while (inputStringIndex <= inputString.Length)
            {
                // stateChanged indicates whether new states have been added to the current set during prediction or completion
                bool stateChanged = true;
                while (stateChanged)
                {
                    stateChanged = false;

                    // Prediction - Expands the left branches of all productions in the current start
                    for (int currentState = 0; currentState < this.states[inputStringIndex].Count; currentState++)
                    {
                        // For each new NT found, find all others and sum the alpha values.
                        // Multiply this sum by RL(Z,Y) for all Y's as appropriate. Add these Y's into the state list.
                        // When Z is re-looked at, Y already exists so the probability will be unaffected.

                        // Is the next symbol in the current state a nonterminal and pending derivation?
                        string pendingSymbol = this.states[inputStringIndex][currentState].PendingSymbol;
                        if (pendingSymbol == null)
                            continue;
                        if (Symbol.IsNonTerminal(pendingSymbol))
                        {
                            // Sum alpha values for all pending Z (pendingSymbol is our current Z)
                            double forwardAlphas = 0.0;
                            for (int alphaStateCount = 0; alphaStateCount < this.states[inputStringIndex].Count; alphaStateCount++)
                            {
                                if (pendingSymbol == this.states[inputStringIndex][alphaStateCount].PendingSymbol)
                                {
                                    forwardAlphas += this.states[inputStringIndex][alphaStateCount].ForwardProbability;
                                }
                            }

                            // Find all Y such that Rl(Z,Y) != 0
                            for (int currentProduction = 0; currentProduction < grammar.Productions.Count; currentProduction++)
                            {
                                if (RL[grammar.Identifiers.IndexOf(pendingSymbol), grammar.Identifiers.IndexOf(grammar.Productions[currentProduction].LHS)] > 0)
                                {
                                    // Appropriate Y found
                                    // Calculate forward probability
                                    double FP = forwardAlphas
                                        * RL[grammar.Identifiers.IndexOf(pendingSymbol), grammar.Identifiers.IndexOf(grammar.Productions[currentProduction].LHS)]
                                        * grammar.Productions[currentProduction].Probability;
                                    double IP = grammar.Productions[currentProduction].Probability;
                                    // VP == IP
                                    State pendingState = new State(grammar.Productions[currentProduction], 0, inputStringIndex, FP, IP, IP);
                                    pendingState.ParentIndex.SetIndex = inputStringIndex;
                                    pendingState.ParentIndex.StateIndex = currentState;
                                    if (!StateExists(pendingState, this.states[inputStringIndex]))
                                    {
                                        // Add new state
                                        this.states[inputStringIndex].Add(pendingState);
                                        stateChanged = true;
                                    }
                                }
                            }
                        }
                    }

                    // Scanning - Appends any symbols in the input stream that are also pending derivations to the next state
                    if (inputStringIndex < inputString.Length)
                    {
                        for (int currentMultipleInput = 0; currentMultipleInput < inputString[inputStringIndex].Count; currentMultipleInput++)
                        {
                            string inputSymbol = String.Copy(inputString[inputStringIndex][currentMultipleInput].Token);
                            double inputProbability = inputString[inputStringIndex][currentMultipleInput].Probability;
                            for (int currentStateIndex = 0; currentStateIndex < this.states[inputStringIndex].Count; currentStateIndex++)
                            {
                                State currentState = this.states[inputStringIndex][currentStateIndex];
                                string pendingSymbol = currentState.PendingSymbol;
                                if (pendingSymbol == null)
                                    continue;
                                if (!Symbol.IsNonTerminal(pendingSymbol))
                                {
                                    if (pendingSymbol == inputSymbol)
                                    {
                                        // Create pending state
                                        State pendingState = new State(currentState.ProductionRule,
                                            currentState.DotPosition + 1,
                                            currentState.Origin,
                                            currentState.ForwardProbability * inputProbability,
                                            currentState.InnerProbability * inputProbability,
                                            currentState.ViterbiProbability);
                                        pendingState.ParentIndex.SetIndex = inputStringIndex;
                                        pendingState.ParentIndex.StateIndex = currentStateIndex;

                                        // If this state does not already exist
                                        if (!StateExists(pendingState, this.states[inputStringIndex + 1]))
                                        {
                                            this.states[inputStringIndex + 1].Add(pendingState);
                                            // Feed completion
                                            State completedState = State.Copy(pendingState);
                                            pendingCompletions.Enqueue(new QueueState(completedState, inputStringIndex + 1));
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Completion
                    while (!pendingCompletions.IsEmpty)
                    {
                        QueueState save = pendingCompletions.Dequeue();
                        int stateIndex = save.SetIndex;
                        State yState = save.State;
                        int origin = yState.Origin;

                        // Do not complete "" -> Production (root productions)
                        if (yState.ProductionRule.LHS == "")
                            continue;

                        // Parent position
                        int yPosition = 0;
 
                        // yState is the outline of the state that requires completion, locate the actual state in the state set
                        for (int yCount = 0; yCount < this.states[stateIndex].Count; yCount++)
                        {
                            if (yState.Equals(this.states[stateIndex][yCount]))
                            {
                                yState = this.states[stateIndex][yCount];
                                yPosition = yCount;
                                break;
                            }
                        }

                        // Search (j) for all Z such that Ru(Z,y) > 0. Then calculate the contribution to the forward and inner probabilities.
					    // for (int ZCount = 0; ZCount < this->States[Origin]->Count; ZCount++)
                        for (int zCount = this.states[origin].Count - 1; zCount >= 0; zCount--)
                        {
                            State zState = this.states[origin][zCount];

                            // Continue if state is completed
                            if (zState.IsCompleted)
                                continue;

                            string zPendingSymbol = zState.PendingSymbol;

                            // if Z is a terminal then continue
                            if (!Symbol.IsNonTerminal(zPendingSymbol))
                                continue;

                            // Check for some symbol Z such that Ru(Z,Y) != 0
                            if (RU[grammar.Identifiers.IndexOf(zPendingSymbol),grammar.Identifiers.IndexOf(yState.ProductionRule.LHS)] <= 0)
                                continue;

                            // Calculate completed state 
                            State cState = State.Copy(zState);

                            // Calculate this completion's probabilities
                            double FP = zState.ForwardProbability
                                * RU[grammar.Identifiers.IndexOf(zPendingSymbol),grammar.Identifiers.IndexOf(yState.ProductionRule.LHS)]
                                * yState.InnerProbability;
                            double IP = zState.InnerProbability
                                * RU[grammar.Identifiers.IndexOf(zPendingSymbol),grammar.Identifiers.IndexOf(yState.ProductionRule.LHS)]
                                * yState.InnerProbability;

                            // Check if completed Z alread exists
                            cState.DotPosition++;

                            if (StateExists(cState, this.states[stateIndex]))
                            {
                                // Update probabilities only for non-unit productions and viterbi links for all states
                                for (int subState = 0; subState < this.states[stateIndex].Count; subState++)
                                {
                                    if (cState.Equals(this.states[stateIndex][subState]))
                                    {
                                        // Not unit production
                                        if (!(yState.ProductionRule.RHS.Length <= 1 && Symbol.IsNonTerminal(yState.ProductionRule.RHS[yState.DotPosition - 1])))
                                        {
                                            this.states[stateIndex][subState].ForwardProbability += FP;
                                            this.states[stateIndex][subState].InnerProbability += IP;
                                            if (this.states[stateIndex][subState].ViterbiProbability < IP)
                                            {
                                                this.states[stateIndex][subState].ViterbiProbability = IP;
                                                this.states[stateIndex][subState].ParentIndex.SetIndex = stateIndex;
                                                this.states[stateIndex][subState].ParentIndex.StateIndex = yPosition;
                                            }
                                            break;
                                        }
                                        // Unit production
                                        else
                                        {
                                            if (this.states[stateIndex][yPosition].ParentIndex.SetIndex == this.states[stateIndex][subState].ParentIndex.SetIndex
                                                && this.states[stateIndex][yPosition].ParentIndex.StateIndex == this.states[stateIndex][subState].ParentIndex.StateIndex)
                                            {
                                                this.states[stateIndex][subState].ParentIndex.SetIndex = stateIndex;
                                                this.states[stateIndex][subState].ParentIndex.StateIndex = yPosition;
                                            }
                                            break;
                                        }
                                    }
                                }
                            }
                            // cState does not exist
                            else
                            {
                                cState.ForwardProbability = FP;
                                cState.InnerProbability = IP;
                                cState.ViterbiProbability = IP;
                                cState.ParentIndex.SetIndex = stateIndex;
                                cState.ParentIndex.StateIndex = yPosition;
                                this.states[stateIndex].Add(cState);
                                stateChanged = true;
                                if (cState.IsCompleted)
                                {
                                    pendingCompletions.Enqueue(new QueueState(cState, stateIndex));
                                }
                            }
                        }
                    }
                }
                inputStringIndex++;
            }
            // Construct the final syntax tree and return.
            return ConstructSyntaxTree(states, grammar.Root);
        }
        #endregion

        #region Helpers
        private bool StateExists(State S, List<State> StateSet)
        {
            for (int CurrentState = 0; CurrentState < StateSet.Count; CurrentState++)
            {
                if (StateSet[CurrentState].ProductionRule.Equals(S.ProductionRule)
                    && StateSet[CurrentState].DotPosition == S.DotPosition
                    && StateSet[CurrentState].Origin == S.Origin)
                    return true;
            }
            return false;
        }

        private static SyntaxTree ConstructSyntaxTree(List<State>[] states, string rootSymbol)
        {
            int finalStateSetIndex = states.Length - 1;

            // Find completed root node
            for (int currentStateIndex = 0; currentStateIndex < states[finalStateSetIndex].Count; currentStateIndex++)
            {
                State currentState = states[finalStateSetIndex][currentStateIndex];
                if (currentState.IsCompleted && currentState.ProductionRule.LHS == "")
                {
                    SyntaxTree ST = new SyntaxTree();
                    ST.Root = ViterbiParse(states, finalStateSetIndex, currentStateIndex);
                    return ST;
                }
            }

            // Only reached if no successful parse tree can be created
            return null;
        }

        private static SyntaxTreeNode ViterbiParse(List<State>[] states, int stateSetIndex, int stateIndex)
        {
            State currentState = State.Copy(states[stateSetIndex][stateIndex]);
            State parentState = State.Copy(states[currentState.ParentIndex.SetIndex][currentState.ParentIndex.StateIndex]);
            if (currentState.DotPosition == 0)
            {
                // This state has no children
                return new SyntaxTreeNode(currentState.ProductionRule.LHS, 0.0);
            }
            else if (!Symbol.IsNonTerminal(currentState.ProductionRule.RHS[currentState.DotPosition - 1]))
            {
                currentState.DotPosition--;
                for (int z = 0; z < states[stateSetIndex - 1].Count; z++)
                {
                    if (currentState.Equals(states[stateSetIndex - 1][z]))
                    {
                        SyntaxTreeNode T = ViterbiParse(states, stateSetIndex - 1, z);
                        SyntaxTreeNode child = new SyntaxTreeNode(currentState.ProductionRule.RHS[currentState.DotPosition], 0.0);
                        child.ForwardProbability = currentState.ForwardProbability;
                        T.Children.Add(child);
                        return T;
                    }
                }
            }
            else
            {
                currentState.DotPosition--;
                int parentIndex = parentState.Origin;

                SyntaxTreeNode T = null;
                for (int z = 0; z < states[parentIndex].Count; z++)
                {
                    if (currentState.Equals(states[parentIndex][z]))
                    {
                        T = ViterbiParse(states, parentIndex, z);
                    }
                }
                SyntaxTreeNode child = ViterbiParse(states, currentState.ParentIndex.SetIndex, currentState.ParentIndex.StateIndex);

                if (T.Symbol == "")
                    T.ForwardProbability = currentState.ForwardProbability;

                T.Children.Add(child);
                return T;
            }
            return null;
        }
        #endregion

    }
}
