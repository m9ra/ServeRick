﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MikePound.Parsing.Earley
{
    /// <summary>
    /// Class that holds the set index and set position of a state stored in the Earley chart parser.
    /// </summary>
    public class StatePosition
    {
        #region Variables
        private int setIndex;
        public int SetIndex
        {
            get
            {
                return setIndex;
            }
            set
            {
                setIndex = value;
            }
        }

        private int stateIndex;
        public int StateIndex
        {
            get
            {
                return stateIndex;
            }
            set
            {
                stateIndex = value;
            }
        }
        #endregion

        #region Contructors
        /// <summary>
        /// Creates a new StatePosition with default (0) values for set and state indexes.
        /// </summary>
        public StatePosition()
        {
            this.setIndex = 0;
            this.stateIndex = 0;
        }

        /// <summary>
        /// Creates a new StatePosition with the supplied values for set and state indexes.
        /// </summary>
        /// <param name="set">The set index of the state in the Earley parser.</param>
        /// <param name="state">The state index of the state inside the set.</param>
        public StatePosition(int set, int state)
        {
            this.setIndex = set;
            this.stateIndex = state;
        }
        #endregion
    }

    /// <summary>
    /// Class that describes a single state inside the Probabilistic Earley chart parser. Holds a production rule, and various
    /// properties required for parsing.
    /// </summary>
    public class State
    {
        #region Variables
        private Production productionRule;
        public Production ProductionRule
        {
            get
            {
                return productionRule;
            }
            set
            {
                productionRule = value;
            }
        }

        private int dotPosition;
        public int DotPosition
        {
            get
            {
                return dotPosition;
            }
            set
            {
                dotPosition = value;
            }
        }

        private int origin;
        public int Origin
        {
            get
            {
                return origin;
            }
            set
            {
                origin = value;
            }
        }

        private double forwardProbability;
        public double ForwardProbability
        {
            get
            {
                return forwardProbability;
            }
            set
            {
                forwardProbability = value;
            }
        }

        private double innerProbability;
        public double InnerProbability
        {
            get
            {
                return innerProbability;
            }
            set
            {
                innerProbability = value;
            }
        }

        private double viterbiProbability;
        public double ViterbiProbability
        {
            get
            {
                return viterbiProbability;
            }
            set
            {
                viterbiProbability = value;
            }
        }

        private StatePosition parentStateIndex;
        public StatePosition ParentIndex
        {
            get
            {
                return parentStateIndex;
            }
            set
            {
                parentStateIndex = value;
            }
        }
        #endregion

        #region Constructors
        /// <summary>
        /// Creates a new State with default values.
        /// </summary>
        public State()
        {
            this.productionRule = null;
            this.dotPosition = 0;
            this.origin = 0;
            this.forwardProbability = 0.0;
            this.innerProbability = 0.0;
            this.viterbiProbability = 0.0;
            this.parentStateIndex = new StatePosition();
        }

        /// <summary>
        /// Creates a state with the provided values.
        /// </summary>
        /// <param name="productionRule">The grammar production rule that was used to generate this state.</param>
        /// <param name="dotPosition">The position of the dot (the current expanded non terminal) in the production.</param>
        /// <param name="origin">The index of the state that generated this state.</param>
        /// <param name="forwardProbability">The forward probability of this state.</param>
        /// <param name="innerProbability">The inner probability of this state.</param>
        /// <param name="viterbiProbability">The viterbi probability of this state.</param>
        public State(Production productionRule, int dotPosition, int origin,
            double forwardProbability, double innerProbability, double viterbiProbability)
        {
            this.productionRule = productionRule;
            this.dotPosition = dotPosition;
            this.origin = origin;
            this.forwardProbability = forwardProbability;
            this.innerProbability = innerProbability;
            this.viterbiProbability = viterbiProbability;
            this.parentStateIndex = new StatePosition();
        }
        #endregion
        
        #region Helpers
        /// <summary>
        /// Creates a new Earley.State based on the properties of the supplied Earley.State.
        /// </summary>
        /// <param name="Input">The state to be copied.</param>
        public static State Copy(State Input)
        {
            State S =  new State(Production.Copy(Input.ProductionRule),
                Input.DotPosition, Input.Origin, Input.ForwardProbability,
                Input.InnerProbability, Input.ViterbiProbability);
            S.ParentIndex.SetIndex = Input.ParentIndex.SetIndex;
            S.ParentIndex.StateIndex = Input.ParentIndex.StateIndex;
            return S;
        }

        /// <summary>
        /// Returns the next symbol in the production rule based on the dot position.
        /// </summary>
        public string PendingSymbol
        {
            get
            {
                if (this.dotPosition >= this.productionRule.RHS.Length)
                    return null;
                else
                    return this.productionRule.RHS[this.dotPosition];
            }
        }

        /// <summary>
        /// Indicates whether a state has been completed based on the dot position.
        /// </summary>
        public bool IsCompleted
        {
            get
            {
                return this.dotPosition >= this.productionRule.RHS.Length;
            }
        }

        /// <summary>
        /// Provides a comparison of the state with another supplied state.
        /// </summary>
        /// <param name="S">The state this state is to be compared with.</param>
        /// <returns>True if the states are identical. False if they are not.</returns>
        public bool Equals(State S)
        {
            return (this.ProductionRule.LHS == S.ProductionRule.LHS
                && RHSEquals(this.ProductionRule.RHS,S.ProductionRule.RHS)
                && this.DotPosition == S.DotPosition
                && this.Origin == S.Origin);
        }

        private bool RHSEquals(string[] RHS1, string[] RHS2)
        {
            if (RHS1.Length != RHS2.Length)
            {
                return false;
            }
            else
            {
                for (int i = 0; i < RHS1.Length; i++)
                {
                    if (RHS1[i] != RHS2[i])
                        return false;
                }
                return true;
            }
            
        }
        #endregion
    }
}